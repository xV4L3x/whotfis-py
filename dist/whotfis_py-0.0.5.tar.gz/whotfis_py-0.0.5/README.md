# whotfis-py
A simple python module to interact with the whois cli
