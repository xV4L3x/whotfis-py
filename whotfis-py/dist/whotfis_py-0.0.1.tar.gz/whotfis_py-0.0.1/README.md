## TODO
- [ ] Check why URLs are not being saved by the parser